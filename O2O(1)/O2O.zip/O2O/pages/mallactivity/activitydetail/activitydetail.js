// pages/mallactivity/activitydetail/activitydetail.js
Page({
  data: {

  },
  onLoad: function (options) {

  },
  linkToSucc(){
    wx.navigateTo({
      url: '/pages/mallactivity/applysucc/applysucc',
    })
  }
})