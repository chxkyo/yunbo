// pages/mysubscribe/mysubscribe.js
Page({
  data: {

  },
  onLoad: function (options) {

  }
})