// pages/coupondetail/coupondetail.js
Page({
  data: {
    state: 1  //优惠券状态：0表示未使用，1表示已使用，2表示已过期
  },
  onLoad: function (options) {
    
  }
})